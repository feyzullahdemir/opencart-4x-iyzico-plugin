<?php
// Text
$_['iyzico_img_title'] 			= '<img style="width: 25%" src="admin/view/image/payment/iyzico_cards.png" alt="iyzico"/>';
$_['payment_failed'] 		  	= 'Ödeme Başarısız';
$_['text_title'] 	 		  	= 'iyzico';
$_['payment_field_desc'] 	 	= 'Ödeme Numarası: ';
$_['installement_field_desc'] 	= 'Taksit Vade Komisyonu';
$_['iyzico_onepage_desc']       = 'Ödeme formu, bilgilerinizi doldurup siparişi tamamla butonuna bastığınız zaman aktif olacaktır.';
