<?php
namespace Opencart\Catalog\Model\Extension\iyzico\Total;
class iyzico extends \Opencart\System\Engine\Model{

    public function confirm($order_info, $order_total){

    }

}
